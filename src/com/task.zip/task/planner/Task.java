package com.task.planner;

import java.util.Objects;
import java.util.UUID;

public class Task {
    private String Title;
    private String Creator;
    private String Assignee;
    private String Status;
    private String Type;
    private String Duedate;
    private String id;

    public Task(String title, String creator, String assignee, String status, String type, String duedate) {
        Title = title;
        Creator = creator;
        Assignee = assignee;
        Status = status;
        Type = type;
        Duedate = duedate;

        this.id = UUID.randomUUID().toString();
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getCreator() {
        return Creator;
    }

    public void setCreator(String creator) {
        Creator = creator;
    }

    public String getAssignee() {
        return Assignee;
    }

    public void setAssignee(String assignee) {
        Assignee = assignee;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }

    public String getDuedate() {
        return Duedate;
    }

    public void setDuedate(String duedate) {
        Duedate = duedate;
    }


    public String getId() {
        return id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Task task = (Task) o;
        return Objects.equals(id, task.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
