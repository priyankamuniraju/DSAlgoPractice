package com.task.planner;

import java.util.Random;

public class Utility {

    public static int[] generateRandomArray(int size, int bound) {
        Random random = new Random();
        int[] arr = new int[size];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = random.nextInt(bound);
            //System.out.print(" " + arr[i]);
        }
        return arr;
    }

    public static boolean isEmpty(String s) {
        return s == null || s.length() == 0;
    }
}
