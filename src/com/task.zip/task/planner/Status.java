package com.task.planner;

public enum Status {
    OPEN, INPROGRESS, COMPLETED
}
