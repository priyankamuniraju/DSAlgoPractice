package com.task.planner;

import com.applications.CannotSetManager;
import com.applications.Employee;
import com.applications.Manager;
import com.applications.ManagerDoesNotExist;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class TaskDriver {

    Map<String,Sprint> sprintMap = new HashMap<>();
    Map<String, Task> allTasks = new HashMap<>();

    public boolean addTaskToSprint(Task task, Sprint sprint) {
        String taskId = task.getId();
        for (String key : sprintMap.keySet()) {
            if (key.equalsIgnoreCase(sprint.getId())) {
                continue;
            }
            Map<String, Task> sprintTasks = sprintMap.get(key).getTasks();
            if (sprintTasks.containsKey(taskId)) {
                return false;
            }
        }
        sprint.getTasks().put(taskId, task);
        return true;
    }

    public boolean removeTaskFromSprint(Task task, Sprint sprint) throws Exception {
        String taskId = task.getId();
        Map<String, Task> taskMap = sprint.getTasks();
        if (taskMap.containsKey(taskId)) {
            taskMap.remove(taskId);
            return true;
        }

        return false;
    }

    public Sprint createSprint(String name) {
        Sprint sprint = new Sprint(name);
        sprintMap.put(sprint.getId(), sprint);
        return sprint;
    }

    public void removeSprint(String id) {
        sprintMap.remove(id);
    }

    public void createTask() {

    }



    public Feature.FeatureImpact parseImpact(String s) {
        switch (s) {
            case "low":
                return Feature.FeatureImpact.LOW;
            case "medium":
                return Feature.FeatureImpact.MEDIUM;
            case "high":
                return Feature.FeatureImpact.HIGH;
        }
        return Feature.FeatureImpact.UNKNOWN;
    }

    public Bug.Severity pasrSeverity(String s) {
        switch (s) {
            case "P1":
                return Bug.Severity.P1;
            case "P0":
                return Bug.Severity.PO;
            case "P2":
                return Bug.Severity.P2;
        }
        return Bug.Severity.UNKNOWN;
    }


    public Task addTask(String[] taskDetails, Sprint sprint) throws ManagerDoesNotExist, CannotSetManager {
        if (taskDetails.length < 6) {
            System.out.println("Please enter a valid input");
            return null;
        }

        String title = taskDetails[0];
        String creator = taskDetails[1];
        String assignee = taskDetails[2];
        String status = taskDetails[3];
        String type = taskDetails[4];
        String dueDate = taskDetails[5];



        if (Utility.isEmpty(title) || Utility.isEmpty(creator)
                || Utility.isEmpty(assignee) || Utility.isEmpty(status)|| Utility.isEmpty(type)||Utility.isEmpty(dueDate)) {
            System.out.println("Please enter valid input! some fields are empty");
            return null;
        }


        Task task = null;
        switch (type) {
            case "feature":
                String featuresummary = taskDetails[6];
                Feature.FeatureImpact impact = parseImpact(taskDetails[7]);

                task = new Feature(title, creator, assignee, status, type, dueDate, featuresummary, impact);
            case "bug":
                Bug.Severity severity = pasrSeverity(taskDetails[6]);
                task = new Bug(title, creator, assignee, status, type, dueDate, severity);
            case "story":
                task = new Story(title, creator, assignee, status, type, dueDate, taskDetails[6],
                        Integer.parseInt(taskDetails[7]));

        }

        if (task == null) {
            System.out.println("Task details provided are incorrect");
            return null;
        }

        allTasks.put(task.getId(), task);
        if (!addTaskToSprint(task, sprint)) {
            return null;
        }

        return task;

    }


    public void readTasksFromConsole() throws CannotSetManager, ManagerDoesNotExist {
        Scanner in = new Scanner(System.in);
        System.out.println("First enter sprint with name and end Enter task details in the format " +
                "title,creator,assignee,status,type," + " on every new line " +
                "dueDate \nIf the type is feature add featuresummary, if type is bug add severity and if type is story add story storysummary,storypoints as additional fields to task" );

        int i = 0;
        Sprint sprint = null;
        while (true) {
            String str = in.nextLine();
            String[] taskDetails = str.split(",");
            if ("end".equalsIgnoreCase(str)) {
                break;
            }
            if (i % 5 == 0) {
                sprint = createSprint(taskDetails[0]);
            }

            Task task = addTask(taskDetails, sprint);
            if (task != null) {
                System.out.println("Task is added successfully To sprint " + sprint.getId() + " with taskId = " + task.getId());
            } else {
                System.out.println("Task cannot be added to the sprint with id " + sprint.getId());
            }
            i++;
        }
    }


    public static void main(String[] args) throws CannotSetManager, ManagerDoesNotExist {
        TaskDriver taskDriver = new TaskDriver();
        taskDriver.readTasksFromConsole();
    }
}
